<?php defined( 'LS_ROOT_FILE' ) || exit; ?>

<!-- SMART ALERT MARKUP -->
<lse-smart-alert-overlay></lse-smart-alert-overlay>
<lse-smart-alert></lse-smart-alert>
